// pages/components/notice.js
const app = getApp()