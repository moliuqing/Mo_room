// pages/components/homepage.js
