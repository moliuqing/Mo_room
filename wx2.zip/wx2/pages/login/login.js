// pages/yiwo/login/login.js
//index.js
//获取应用实例
var app = getApp()

Page({
  data: {
    userName: '',//存储值，后面属于判断取舍并不一定等于输入值
    passWd: '',
    userN: '', //输入值  
    passW: '',     
    loginToast: true
  },
  //用户名，手机号，密码输入框
  userNameInput: function (e) {
    //setData 函数用于将数据从逻辑层发送到视图层，同时改变对应的 this.data 的值。
    this.setData({
      userN: e.detail.value
    })
  },
  passWdInput: function (e) {
    this.setData({
      passW: e.detail.value
    })
  },
  //登录按钮点击事件，调用参数要用：this.data.参数；
  loginBtnClick: function () {

    var userName = this.data.userN;
    var passWd = this.data.passW;
    //最长不得超过4个汉字，或14个字节(数字，字母和下划线)
    var uPattern = /^[\u4e00-\u9fa5]{1,4}$|^[\dA-Za-z_]{1,14}$/;

    if (userName == '' || userName == null) {
      wx.showToast({
        title: '用户名不能为空',
        icon: 'none',
        duration: 2000
      }) 
      return;
    }
    if (!uPattern.test(userName)) {
      wx.showToast({
        title: '用户名格式不正确',
        icon: 'none',
        duration: 2000
      })   
      return;
    }
    if (passWd == '' || passWd == null) {
      console.log("密码不能为空");
      wx.showToast({
        title: '密码不能为空',
        icon: 'none',
        duration: 2000
      })
      return;
    }

    console.log(userName, passWd);

    wx.showToast({
      title: '加载中',
      icon: 'loading'
    })

    // 记住密码,你也可以放到请求数据成功的里面，这样用户输错信息，就不会记住错误的密码
    // 跳转带有tab的界面使用：wx.switchTab({ url: "../home/home" });
    //创建新的对象，把上面的输入值都存到此对象里
    var obj = new Object();
    obj.name = userName;
    obj.pswd = passWd;
    console.log('obj', obj);
    

    // 最后再进行MD5加密，这里假设数据请求成功直接跳转界面
    // var request = true;
    // if (request) {
    //   wx.navigateTo({
    //     url: "../index/index?" +
    //     "userName=" + userName + "&" +
    //     "passWd=" + passWd,
    //     success: function (res) {
    //       console.log('ok');
    //     },
    //     fail: function (res) {
    //       // fail
    //     },
    //     complete: function (res) {
    //       // complete
    //     }
    //   })
    // }
    if (userName && passWd) {
      // 同步方式存储表单数据
      wx.setStorageSync('userName', obj.name);
      wx.setStorageSync('passWd', obj.pswd);
      console.log('userName', userName);
      console.log('passWd', passWd);
      wx.switchTab({
        url: '/pages/index/index',
        success: function (res) {
          console.log('ok');
        },
        fail: function (res) {
          // fail
        },
        complete: function (res) {
          // complete
        }
      })
    }
    // 发送网络请求
    // wx.request({
    //   url: XXX,XXX,XXX,
    //   data: { AGENTID: userName, PSWD: Md5(passWd), PHONE: userPhone, target: 1 },
    //   method: 'POST',
    //   header: {
    //     "content-type": "application/x-www-form-urlencoded"
    //   },
    //   success: function (res) {
    //     // success
    //     var loginInfo = res.data
    //     console.log(loginInfo);
    //     if (loginInfo.code == 1) {
    //     console.log(res.data);
    // 记住密码
    //     var obj = new Object();
    //     obj.name = userName;
    //     obj.pswd = passWd;
    //     obj.phone = userPhone;
    //     console.log('obj', obj);
    //     that.setSaveData(rui, obj);
    //       // 登录记录
    //       var logs = wx.getStorageSync(loginList) || []
    //       logs.unshift(Date.now())
    //       wx.setStorageSync(loginList, logs)

    //       // 至主页
    //       wx.switchTab({ url: "../home/home" });
    //       toast(loginInfo.msg);
    //     } else {
    //       var msg = loginInfo.msg;
    //       toast(loginInfo.msg);
    //     }
    //   },
    //   fail: function (res) {
    //     // fail
    //     toast('登录失败,请重试');
    //     console.log('登录失败:', res);
    //   },
    //   complete: function () {
    //     // complete
    //     console.log('comlete');
    //   }
    // })
  },

})
function toast(toast) {
  wx.showToast({
    title: toast,
    duration: 2000
  })
}


